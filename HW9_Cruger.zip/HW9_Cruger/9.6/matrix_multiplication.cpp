#include <vector>
//#include <C:\Users\LEWIS\Documents\origin\math\matrix\matrix.hpp>
#include <origin/math/matrix/matrix.hpp>
#include <iostream>

using std::cout;
using std::endl;

/*
NOTE: had trouble including the origin library. I added a line with the include the way it should be for you,
and used my work around (commented out) to get this to compile. I'm not sure why origin isn't including correctly, I'm including
the same way I include boost. 

If there are any issues picking up the matrix.hpp file, please check your include. I had a friend compile this on their machine
and it worked fine.
*/

int main()
{
	// make the 2d matrix of interest easier to use
	typedef origin::matrix<int, 2> M; // using M = origin::matrix<double,2>;

	// basic use
	
	M m4x5a(4,5);
	m4x5a = { { 0, 1, 2, 3, 4 }, { 10, 11, 12, 13, 14 }, { 20, 21, 22, 23, 24 }, { 30, 31, 32, 33, 34 } };
	M m5x4b(5,4);
	m5x4b = { { 0, 1, 1, 1 }, { 2, 0, 2, 2 }, { 3, 3, 0, 3 }, { 4, 4, 4, 0 }, { 5, 5, 5, 5 } };

	M mproduct = m4x5a * m5x4b;

	cout << mproduct << endl;
}


