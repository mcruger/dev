#include <iostream>;

using namespace std;

int f() {
cout << "Some text";
g(); // g and h are functions whose
cout << h(); // definitions are unknown
cout.flush();
return 0;
}

//exceptions would cause this to not work