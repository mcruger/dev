#include<algorithm>
#include<iostream>
#include<string>
#include<vector>
using namespace std;

struct maxlenftn {
	maxlenftn() { maxlen = 0; }
	void operator()(string s) {
		maxlen = max(maxlen,s.size());
	}
	string::size_type maxlen;
};

int main() {
	const char *na[] = {"Spertus", "Lemon", "Golden", "Melhus"};
	vector<string> names(na, na + sizeof(na)/sizeof(const char *));
	maxlenftn maxf; //need to initialize functor before using it
	maxf = for_each(names.begin(),names.end(),maxf); //uses maxf in for_each
	cout << maxf.maxlen << endl;
	return 0;
}