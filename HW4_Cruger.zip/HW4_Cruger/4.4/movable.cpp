//reference: http://msdn.microsoft.com/en-us/library/dd293665.aspx

#include<iostream>

using namespace std;

struct node
{
  int key_value;
  node *left;
  node *right;
};


class btree
{
    public:
        btree();
        ~btree();

        void insert(int key);
        node *search(int key);
        void destroy_tree();

		// Copy constructor.
	   btree(const btree& other) : root(other.root)
	   {
		  copy(other.root, other.root + sizeof(root), root);
	   }

      // Copy assignment operator.
	   btree& operator=(const btree& other)
	   {
		  //std::cout << "In operator=(const MemoryBlock&). length = " << other._length << ". Copying resource." << std::endl;

		  if (this != &other)
		  {
			 // free the existing root.
			 delete root;
			 root = other.root;
			 copy(other.root, other.root + sizeof(root), root);
		  }
		  return *this;
	   }

	   // Move constructor.
		btree(btree&& other)
		   : root(NULL)
		{
		   //std::cout << "In MemoryBlock(MemoryBlock&&). length = " << other._length << ". Moving resource." << std::endl;

		   // copy the data pointer 
		   root = other.root;
		   // release the data pointer from the source object so that the destructor does not free the memory multiple times.
		   other.root = NULL;
		}

		// Move assignment operator.
		btree& operator=(btree&& other)
		{
		   //std::cout << "In operator=(MemoryBlock&&). length = " << other._length << "." << std::endl;

		   if (this != &other)
		   {
			  // free the existing resource.
			  delete[] root;
			  // copy the data pointer from the source object
			  root = other.root;
			  // release the data pointer from source object so destructor does not free mem multiple times
			  other.root = NULL;
		   }
		   return *this;
		}


    private:
        void destroy_tree(node *leaf);
        void insert(int key, node *leaf);
        node *search(int key, node *leaf);
        
        node *root;
};

btree::btree()
{
  root=NULL;
}

btree::~btree()
{
  destroy_tree();
}

void btree::destroy_tree(node *leaf)
{
  if(leaf!=NULL)
  {
    destroy_tree(leaf->left);
    destroy_tree(leaf->right);
    delete leaf;
  }
}

void btree::insert(int key, node *leaf)
{
  if(key< leaf->key_value)
  {
    if(leaf->left!=NULL)
     insert(key, leaf->left);
    else
    {
      leaf->left=new node;
      leaf->left->key_value=key;
      leaf->left->left=NULL;    //Sets the left child of the child node to null
      leaf->left->right=NULL;   //Sets the right child of the child node to null
    }  
  }
  else if(key>=leaf->key_value)
  {
    if(leaf->right!=NULL)
      insert(key, leaf->right);
    else
    {
      leaf->right=new node;
      leaf->right->key_value=key;
      leaf->right->left=NULL;  //Sets the left child of the child node to null
      leaf->right->right=NULL; //Sets the right child of the child node to null
    }
  }
}

node *btree::search(int key, node *leaf)
{
  if(leaf!=NULL)
  {
    if(key==leaf->key_value)
      return leaf;
    if(key<leaf->key_value)
      return search(key, leaf->left);
    else
      return search(key, leaf->right);
  }
  else return NULL;
}

void btree::insert(int key)
{
  if(root!=NULL)
    insert(key, root);
  else
  {
    root=new node;
    root->key_value=key;
    root->left=NULL;
    root->right=NULL;
  }
}

node *btree::search(int key)
{
  return search(key, root);
}

void btree::destroy_tree()
{
  destroy_tree(root);
}

int main()
{
	return 0;
}