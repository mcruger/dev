int main()
{
int i;
int *ip = new int[10];
delete &i;
delete [ip];
return 0;
}

//don't really need to delete anything for i
//square brackets on ip