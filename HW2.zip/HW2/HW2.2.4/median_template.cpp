#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

//*********************************
// Note: I'm using the average of 2 middle elements for even length vectors for extra credit
//
// Uses a template to find median
//*********************************


template<typename T>
T median(vector<T> myvector)
{
	int size = myvector.size();
	if (size % 2 == 0){
		//even, find average of 2 middle elements
		nth_element(myvector.begin(), myvector.begin()+myvector.size()/2+1, myvector.end());
		nth_element(myvector.begin(), myvector.begin()+myvector.size()/2, myvector.end());
		return (myvector.at(size / 2 - 1) + myvector.at(size / 2)) / 2;
	}else{
		//odd, return median
		nth_element(myvector.begin(), myvector.begin()+myvector.size()/2+1, myvector.end());
		return myvector.at(size / 2);
	}
}

int main(){

	//DOUBLES
	//init vectors of even and odd length
	double mydoubles[] = {32, 71, 12, 45, 26, 80, 53, 33, 92}; //sorted: 12 26 32 33 45 53 71 80 92
	vector<double> myvectorD_even(begin(mydoubles), end(mydoubles)-1); 
	vector<double> myvectorD_odd(begin(mydoubles), end(mydoubles));
	//find medians of each vector
	double medD_even = median(myvectorD_even);
	double medD_odd = median(myvectorD_odd);

	//FLOATS
	//init vectors of even and odd length
	float myfloats[] = {32, 71, 12, 45, 26, 80, 53, 33, 92}; //sorted: 12 26 32 33 45 53 71 80 92
	vector<float> myvectorF_even(begin(myfloats), end(myfloats)-1); 
	vector<float> myvectorF_odd(begin(myfloats), end(myfloats));
	//find medians of each vector
	double medF_even = median(myvectorF_even);
	double medF_odd = median(myvectorF_odd);

	//INTS
	//init vectors of even and odd length
	int myints[] = {32, 71, 12, 45, 26, 80, 53, 33, 92}; //sorted: 12 26 32 33 45 53 71 80 92
	vector<int> myvectorI_even(begin(myints), end(myints)-1); 
	vector<float> myvectorI_odd(begin(myints), end(myints));
	//find medians of each vector
	double medI_even = median(myvectorI_even);
	double medI_odd = median(myvectorI_odd);

	//output results
	cout << "using a template and nth_element" << endl;
	cout << "even vector median should be 39, odd vector median 45 (as specified type)" << endl;
	cout << "doubles:" << endl;
	cout << "even vector median: " << medD_even << endl;
	cout << "odd vector median: " << medD_odd << endl;
	cout << "floats:" << endl;
	cout << "even vector median: " << medF_even << endl;
	cout << "odd vector median: " << medF_odd << endl;
	cout << "ints:" << endl;
	cout << "even vector median: " << medI_even << endl;
	cout << "odd vector median: " << medI_odd << endl;

	return 0;

}