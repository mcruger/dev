#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

//*********************************
// Note: I'm using the average of 2 middle elements for even length vectors for extra credit
//
// nth_element is faster than sort and partial_sort
// Googling tells me that the average time complexity is linear at O(n), while worst case in some implementations is O(n*n)
//*********************************

//finds the median of a vector using the median function
double median(vector<double> myvector){
	int size = myvector.size();
	if (size % 2 == 0){
		//even, find average of 2 middle elements
		nth_element(myvector.begin(), myvector.begin()+myvector.size()/2+1, myvector.end());
		nth_element(myvector.begin(), myvector.begin()+myvector.size()/2, myvector.end());
		return (myvector.at(size / 2 - 1) + myvector.at(size / 2)) / 2;
	}else{
		//odd, return median
		nth_element(myvector.begin(), myvector.begin()+myvector.size()/2+1, myvector.end());
		return myvector.at(size / 2);
	}
}

int main(){

	//init vectors of even and odd length
	double mydoubles[] = {32, 71, 12, 45, 26, 80, 53, 33, 92}; //sorted: 12 26 32 33 45 53 71 80 92
	vector<double> myvector_even(begin(mydoubles), end(mydoubles)-1); 
	vector<double> myvector_odd(begin(mydoubles), end(mydoubles));

	//find medians of each vector
	double med_even = median(myvector_even);
	double med_odd = median(myvector_odd);

	//output results
	cout << "using nth_element" << endl;
	cout << "even vector median should be 39, odd vector median 45 (as doubles)" << endl;
	cout << "even vector median: " << med_even << endl;
	cout << "odd vector median: " << med_odd << endl;

	return 0;

}