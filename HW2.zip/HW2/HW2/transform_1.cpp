#include <vector>
#include <algorithm>
#include <iterator>
#include <iostream>
#include <cmath>

using namespace std;

//square and return a number
float square_num(float n) { 
	float square = pow(n, 2);  
	return square; 
}

int main() {
	   
	  vector<float> orig;
	  vector<float> trans;

	  //fill orig vector with 10 floats
	  for (float i=1; i<10; i++){
		orig.push_back (i*5);                      
	  }

	  //allocate space for trans vector
	  //fill it with squares from origin vector using transform
	  trans.resize(orig.size());                         
	  transform(orig.begin(), orig.end(), trans.begin(), square_num);
      
	  //output results
	  cout << "The \"transformed\" vector contains:";
	  ostream_iterator<float> out_it (cout,", ");
	  for (vector<float>::iterator it=trans.begin(); it!=trans.end(); ++it){
		cout << ' ' << *it;
	  }
	  cout << '\n';

	  return 0;
}

