// NOTE: I had to do some googling for this one. The below stack overflow post cleared this up for me.
// My code is pretty much copy/paste from the stack overflow thread.
// http://stackoverflow.com/questions/99552/where-do-pure-virtual-function-call-crashes-come-from

//base class
class Base
{
public:
    Base() { doIt(); }  // DON'T DO THIS
    virtual void doIt() = 0;
};

//derived class
class Derived : public Base
{
    void doIt() {}
};

int main(void)
{
    Derived d;  // This will cause "pure virtual function call" error (non_existent_method error)
}

