/*
Pascal from week1 written with classes.
*/

#include<iostream>
using namespace std;

class PascalTriangle{

	int num_rows; 
    public:
	PascalTriangle(int);

	void print(){
		for (int i = 0; i < num_rows; i++)
		{
			int val = 1; //start value at 1
			for (int j = 1; j < (num_rows - i); j++)
			{
				cout << "   "; //3 spaces 
			}
			for (int k = 0; k <= i; k++)
			{	
				if ( val - 10 < 0 ){
					cout << "     " << val; //5 spaces
				}else{
					cout << "    " << val; //4 spaces
				}
				val = val * (i - k) / (k + 1); 
			}
			cout << endl << endl;
		}
		cout << endl;
	}

};

PascalTriangle::PascalTriangle (int rows){
	num_rows = rows;
}

int main()
{
	//instantiate pascal tri object w/ 9 rows
	PascalTriangle tri (9);
	
	// print the triangle
	tri.print(); 
	
	return 0;
}