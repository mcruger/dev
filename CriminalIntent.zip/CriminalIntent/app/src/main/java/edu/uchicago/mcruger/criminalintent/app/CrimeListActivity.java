package edu.uchicago.mcruger.criminalintent.app;

import android.support.v4.app.Fragment;

/**
 * Created by LEWIS on 4/23/2014.
 */
public class CrimeListActivity extends SingleFragmentActivity{

    @Override
    protected Fragment createFragment(){
        return new CrimeListFragment();
    }

}
