package edu.uchicago.mcruger.criminalintent.app;

import java.util.Date;
import java.util.UUID;

/**
 * Created by LEWIS on 4/22/2014.
 */
public class Crime {

    private UUID mId;
    private String mTitle;
    private Date mDate;
    private boolean mSolved;

    public Crime (){
        //generate unique identifier
        mId = UUID.randomUUID();
        mDate = new Date();
    }

    @Override
    public String toString(){
        return mTitle;
    }

    public String getmTitle() {
        return mTitle;
    }

    public UUID getmId() {
        return mId;
    }

    public void setmTitle(String mTitle) {
        this.mTitle = mTitle;
    }

    public boolean ismSolved() {
        return mSolved;
    }

    public void setmSolved(boolean mSolved) {
        this.mSolved = mSolved;
    }

    public Date getmDate() {


        return mDate;
    }

    public void setmDate(Date mDate) {
        this.mDate = mDate;
    }

}
