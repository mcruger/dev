//reference: http://www.cprogramming.com/tutorial/operator_overloading.html

#include <iostream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <numeric>

using namespace std;

class ComplexInt
{
public:
		//constructor
        ComplexInt(int r, int i) :real(r),imaginary(i) {};
        ComplexInt operator+(const ComplexInt& other);
        ComplexInt operator*(const ComplexInt& other);
private:
		//properties
        int real;
		int imaginary;

//need to overload << for output
friend ostream &operator<<(ostream &out, ComplexInt c)     
{
        cout << "result: "<< c.real <<" + " << c.imaginary<<"i ";
        return out;
}

};

//addition operator overload
ComplexInt ComplexInt::operator+(const ComplexInt&  other)
{
    int result_real = real + other.real;
    int result_imaginary = imaginary + other.imaginary;
    return ComplexInt( result_real, result_imaginary );
}

//multiplication operator overload
ComplexInt ComplexInt::operator*(const ComplexInt&  other)
{
    int result_real = real * other.real;
    int result_imaginary = imaginary * other.imaginary;
    return ComplexInt( result_real, result_imaginary );
}


int
main()
{

	ComplexInt a(3,2);
	ComplexInt b(1,1);

	cout << "a(3,2):" << endl;
	cout << a << endl;
	cout << "b(1,1):" << endl;
	cout << b << endl;
	cout << "Addition of a(3,2) and b(1,1):" << endl;
	cout << a + b << endl; 
	cout << "Multiplication of a(3,2) and b(1,1):" << endl;
	cout << a * b << endl; 
}