//reference: http://www.cprogramming.com/tutorial/operator_overloading.html

/*README

NOTE: No versions of visual studio support user defined literals.
http://msdn.microsoft.com/en-us/library/hh567368.aspx

Did the best I could with this, and according to Google it should work

*/

#include <iostream>
#include <sstream>
#include <complex>

using namespace std;

//imaginary numbers UDL
//not supported by Visual Studio, couldn't test, but should work
std::complex<long double> operator "" _i(long double d)
{ 
    return std::complex<long double>(0, d); 
}


int
main()
{
	auto val = 3.14_i; // val = complex<long double>(0, 3.14)
	cout << val << endl;
}