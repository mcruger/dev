//reference: http://www.cprogramming.com/tutorial/operator_overloading.html


#include <iostream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <numeric>

using namespace std;

/*

Had a log of difficulty with this problem, but it should be 
compiling correctly. Not sure if I can't overload my + and * operators
outside of my template class declaration due to a Visual Studio compiler
thing, but I just couldn't get it to work even though it should be working
per my googling.

*/


template <typename T>
class Complex
{
public:
		//construct complex nums with and without imaginary
        Complex(T r, T i) :real(r),imaginary(i) {};
		Complex(T r) :real(r) {};
		//needed to include overloaded operators with class to get this to work, not sure why it matters
        //ComplexInt operator+(const ComplexInt& other);
        //ComplexInt operator*(const ComplexInt& other);

	//addition operator overload - note, needed to include with class
	Complex operator+(const Complex& other)
	{
		T result_real = real + other.real;
		T result_imaginary = imaginary + other.imaginary;
		return Complex( result_real, result_imaginary );
	}

	//multiplication operator overload - note, needed to include with class
	Complex operator*(const Complex& other)
	{
		T result_real = real * other.real;
		T result_imaginary = imaginary * other.imaginary;
		return Complex( result_real, result_imaginary );
	}

private:
        T real;
		T imaginary;

//need to overload << for output
friend ostream &operator<<(ostream &out, Complex c)     
{
        cout << "result: "<< c.real <<" + " << c.imaginary<<"i ";
        return out;
}

};


/*
//NEEDED TO MOVE OVERLOADED OPERATORS INTO CLASS - COULDN'T GET IT TO COMPILE SEPARATELY
template <class T> T Complex<T>::operator+(const T &num){
   T func_real = real + num.real;
   T func_imag = imag + num.imag;
   return Complex(func_real,func_imag);
}

template <class T> T Complex<T>::operator*(const T &num){
   T func_real = (real*num.real) - (imaginary*num.imaginary);
   T func_imag = (real*num.imaginary) + (imaginary*num.real);
   return Complex(func_real,func_imag);
}
*/


int
main()
{

	Complex<int> a(3, 2);
	Complex<int> b(1, 1);
	Complex<double> c(3.1, 1.5);
	Complex<double> d(4.5, 2.1);
	Complex<int> e(3);

//cout << a << b;
	cout << "Addition of a(3,2) and b(1,1):" << endl;
	cout << a + b << endl; 
	cout << "Multiplication of a(3,2) and b(1,1):" << endl;
	cout << a * b << endl; 
	cout << "Addition of c(3.1,1.5) and d(4.5,2.1):" << endl;
	cout << c + d<< endl; 
	cout << "Multiplication of c(3.1,1.5) and d(4.5,2.1):" << endl;
	cout << c * d<< endl;
	//cout << "e(3) + a(3,2)" << endl;
	//cout << e + a<< endl;
	//cout << "e(3) " << endl;
	cout << e << endl;
}