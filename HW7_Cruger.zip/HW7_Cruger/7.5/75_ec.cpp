
/*

http://www.cplusplus.com/reference/iomanip/setw/

Output looks OK to me. From the doc above, setw() is modifying the output line.
I'm guessing this is supposed to be breaking the output? 
For me, it just adds some spaces to the left of the output to take up 10 lines.
I'm thinking the solution would be to include the setw() functionality inside
of the << overloaded operator method.

*/


#include <iostream>
#include <sstream>
#include <algorithm>
#include <iomanip>
#include <numeric>

using namespace std;

class ComplexInt
{
public:
        ComplexInt(int r, int i) :real(r),imaginary(i) {};
        ComplexInt operator+(const ComplexInt& other);
        ComplexInt operator*(const ComplexInt& other);
private:
        int real;
		int imaginary;

//need to overload << for output
friend ostream &operator<<(ostream &out, ComplexInt c)     
{
        cout << "result: "<< c.real <<" + " << c.imaginary<<"i ";
        return out;
}

};

//addition operator overload
ComplexInt ComplexInt::operator+(const ComplexInt&  other)
{
    int result_real = real + other.real;
    int result_imaginary = imaginary + other.imaginary;
    return ComplexInt( result_real, result_imaginary );
}

//multiplication operator overload
ComplexInt ComplexInt::operator*(const ComplexInt&  other)
{
    int result_real = real * other.real;
    int result_imaginary = imaginary * other.imaginary;
    return ComplexInt( result_real, result_imaginary );
}



int
main()
{


	ComplexInt ci(2, 7); // 2 + 7i
	cout << setw(10) << ci << endl;

	system("pause");

}