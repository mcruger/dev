#include <vector>
#include <iterator>
#include <iostream>
#include <cmath>
#include <numeric>

using namespace std;

//called by accumulate. squares next number and adds it to previous number
float square_num(float x, float y) { 
	return x + (y*y); 
}

int main() {

	vector<float> orig;

	//fill orig vector with 10 floats
	for (float i=1; i<10; i++){
		orig.push_back (i*5);                      
	}                       

	//compute sum of square roots of values in orig vector using accumulate
	float init = 0;
	float sum = accumulate(orig.begin(), orig.end(), init, square_num);
	float square_root = sqrt(sum);

	//output results
	cout << "Sum with accumulate (not using transform): ";
	cout << sum;
	cout << '\n';
	cout << "Square root: ";
	cout << square_root;
	cout << '\n';

	return 0;
}

