#include <algorithm>
#include <iostream>
#include <vector>

using namespace std;

//*********************************
// Note: I'm using the average of 2 middle elements for even length vectors for extra credit
//
// On average, partial_sort should be faster than sort because it's only sorting a portion of the vector.
// From some research, sort has a time complexity of O(nlog(n)) and partial_sort has a time complexity of O((last-first)log(middle-first))).
//*********************************

//finds the median of a vector using the partial_sort function
double median(vector<double> myvector){
	partial_sort(myvector.begin(), myvector.begin()+myvector.size()/2+1, myvector.end());
	int size = myvector.size();
	if (size % 2 == 0){
		//even, find average of 2 middle elements
		return (myvector.at(size / 2 - 1) + myvector.at(size / 2)) / 2;
	}else{
		//odd, return median
		return myvector.at(size / 2);
	}
}

int main(){

	//init vectors of even and odd length
	double mydoubles[] = {32, 71, 12, 45, 26, 80, 53, 33, 92}; //sorted: 12 26 32 33 45 53 71 80 92
	vector<double> myvector_even(begin(mydoubles), end(mydoubles)-1); 
	vector<double> myvector_odd(begin(mydoubles), end(mydoubles));

	//find medians of each vector
	double med_even = median(myvector_even);
	double med_odd = median(myvector_odd);

	//output results
	cout << "using partial_sort" << endl;
	cout << "even vector median should be 39, odd vector median 45 (as doubles)" << endl;
	cout << "even vector median: " << med_even << endl;
	cout << "odd vector median: " << med_odd << endl;

	return 0;

}