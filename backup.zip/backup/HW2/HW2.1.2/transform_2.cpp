#include <vector>
#include <algorithm>
#include <iterator>
#include <iostream>
#include <cmath>
#include <numeric>

using namespace std;

//square and return a number
float square_num(float n) { 
	float square = pow(n, 2);  
	return square; 
}

int main() {

	vector<float> orig;
	vector<float> trans;

	//fill orig vector with 10 floats
	for (float i=1; i<10; i++){
		orig.push_back (i*5);                      
	}

	//allocate space for trans vector
	//fill it with squares from origin vector using transform
	trans.resize(orig.size());                         
	transform(orig.begin(), orig.end(), trans.begin(), square_num);
    
	//output contents of trans vector
	cout << "The \"transformed\" vector contains:";
	ostream_iterator<float> out_it (cout,", ");
	for (vector<float>::iterator it=trans.begin(); it!=trans.end(); ++it){
		cout << ' ' << *it;
	}
	cout << '\n';

	//sum contents of trans vector using accumulate and compute sqrt
	float init = 0;
	float sum = accumulate(trans.begin(), trans.end(), init);
	float square_root = sqrt(sum);

	//output results
	cout << "Sum with accumulate: ";
	cout << sum;
	cout << '\n';
	cout << "Square root: ";
	cout << square_root;
	cout << '\n';
	
	return 0;
}

